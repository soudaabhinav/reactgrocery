export {default as FoodCard} from './Card'





