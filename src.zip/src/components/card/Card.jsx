import './Card.css';

const Card=({datum})=>{

    return( <div className='card'>

    <div className='imgee'>
      <img src={datum.image}></img>
      
    </div>
    <p className='wei'>{datum.unit}</p>

    <p className='vegn'>{datum.title}</p>

    <p className='pri'>{datum.price}</p>



  </div>)



}

export default Card