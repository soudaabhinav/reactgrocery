import './App.css';
  import ReactDOM from 'react-dom'
  import image from './cal.png';
  import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
  import { faArrowRight, faCoffee, faRightLeft } from '@fortawesome/free-solid-svg-icons'
  import  {FoodCard} from './components/card';
  import db from './DB';


function App() {
  const {weeklySpecial}=db
  return (
    <div className="App">

      <div className='weekly'>

      <div className='wtext'>
        <p>Weekly Special</p>
        </div>

        
        
        

        <div className='vtext'>
        <p>view all </p>


        <FontAwesomeIcon className='ico'icon={ faArrowRight }></FontAwesomeIcon>

        
          
        
        
        </div>

      {
weeklySpecial.map((datum)=>{
  return( <FoodCard datum={datum}/> )

})
      }
       
    






        



      </div>

      </div>

      
      
    
  )
}

export default App;
