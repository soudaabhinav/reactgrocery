

const weeklySpecial=[{ image:require("./assets/cal.png"),unit:"250g",title:"Chinese Cabbage",price:"$1.65"

},

{ image:require("./assets/cal.png"),unit:"1 Kg",title:"Tata Salt Litelow Sodium Iodised",price:"$2.99"

},
{ image:require("./assets/cal.png"),unit:"Each One",title:"Fresh Avacoda",price:"$0.99"

},
{ image:"./assets/cal.png",unit:"50 g",title:"Knorr Thick Tomato Soup",price:"$2.99"

},
{ image:"./assets/cal.png",unit:"120g",title:"Meera Herbal Hairwash Powder",price:"$4.99"

}

]

export default {
    weeklySpecial
}